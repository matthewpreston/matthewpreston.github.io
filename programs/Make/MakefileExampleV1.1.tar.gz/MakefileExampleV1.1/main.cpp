#include <iostream>
#include "Parrot.hpp"

int main(int argc, char *argv[]) {
	Parrot avianBeing = Parrot("Polly isn't fond of crackers");
	avianBeing.Speak(std::cout);
	return 0;
}