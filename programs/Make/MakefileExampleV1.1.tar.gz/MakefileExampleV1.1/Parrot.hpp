#ifndef PARROT_H
#define PARROT_H

#include <ostream>
#include <string>

// Give it a phrase and you'll never hear the end of it.
class Parrot {
public:
	Parrot(std::string Phrase) : phrase(Phrase) {}
	// Echoes the provided phrase to a given output stream
	void Speak(std::ostream &os);
private:
	std::string phrase;
};

#endif