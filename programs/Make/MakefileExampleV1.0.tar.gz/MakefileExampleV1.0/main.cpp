#include <iostream>

int main(int argc, char *argv[]) {
	std::cout << "Goodbye, cruel world!" << std::endl;
	return 0;
}