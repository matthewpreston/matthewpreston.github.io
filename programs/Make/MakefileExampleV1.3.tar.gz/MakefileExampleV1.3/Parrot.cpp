#include <ostream>
#include <string>
#include "Parrot.hpp"

// Echoes the provided phrase to a given output stream
void Parrot::Speak(std::ostream &os) {
	os << phrase << std::endl;
}