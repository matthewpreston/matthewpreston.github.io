#include <iostream>
#include <string>
#include <vector>
#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>
#include "Parrot.hpp"

namespace {
	const int SUCCESS                   = 0;
	const int ERROR_IN_COMMAND_LINE     = 1;
	const int ERROR_UNHANDLED_EXCEPTION = 2;
}

namespace po = boost::program_options;

int main(int argc, char *argv[]) {
	try {
		int osType;
		std::vector<std::string> phrases;
		
		// Add optional arguments
		po::options_description desc("Options");
		desc.add_options()
			("help,h", "Display help")
			("output_stream,o", po::value<int>(&osType)
				->value_name("INT")->default_value(1),
				"1 for STDOUT, 2 for STDERR")
			("phrase", po::value< std::vector<std::string> >(&phrases)
				->multitoken()->composing()->required(),
				"Phrase to be parroted back")
		;
		
		// Add positional arguments
		po::positional_options_description positional;
		positional.add("phrase", -1);
		
		// Set up variable map
		po::variables_map vm;
		try {
			po::store(po::command_line_parser(argc, argv).options(desc)
					  .positional(positional).run(), vm);
			
			// Check help first in order to exit
			if (vm.count("help")) {
				std::string exe = boost::filesystem::basename(argv[0]);
				std::cout << "USAGE: " << exe << " [options] <phrase>...\n\n"
						  << desc << std::endl;
				return SUCCESS;
			}
			
			// Parse arguments and check constraints
			po::notify(vm);
		} catch (po::required_option &e) {
			std::cerr << "Missing required option.\nTraceback:\n"
					  << e.what() << std::endl;
			return ERROR_IN_COMMAND_LINE;
		} catch (po::error &e) {
			std::cerr << "An unexpected argument parsing error occurred.\n"
					  << "Traceback:\n" << e.what() << std::endl;
			return ERROR_IN_COMMAND_LINE;
		}
		
		// Check our arguments
		if (vm.count("output_stream")) {
			if (osType < 1 || osType > 2) { // Not STDOUT or STDERR
				std::cerr << "Output stream is neither STDOUT or STDERR, "
						  << "exiting" << std::endl;
				return ERROR_IN_COMMAND_LINE;
			}
		}
		
		// Compile our phrase
		std::string phrase = "";
		for (std::vector<std::string>::iterator it = phrases.begin();
			 it != phrases.end();
			 it++)
		{
			if (phrase == "") {
				phrase = *it;
			} else {
				phrase += " " + *it;
			}
		}
		
		// Let our pet speak
		Parrot avianBeing = Parrot(phrase);
		avianBeing.Speak((osType == 1) ? std::cout : std::cerr);
		return SUCCESS;

	} catch (std::exception &e) {
		std::cerr << "An unexpected error in main occurred.\nTraceback:\n"
				  << e.what() << std::endl;
		return ERROR_UNHANDLED_EXCEPTION;
	}
}