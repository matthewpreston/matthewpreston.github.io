#!/bin/bash

blastProgs="blastn|blastp|blastx|tblastn|tblastx"

#Ensure all blast jobs are done
blastJobs=($(ps -e | grep -E $blastProgs))
while [ ${#blastJobs[@]} -gt 0 ]; do
	sleep 1m
	blastJobs=($(ps -e | grep -E $blastProgs))
done

#Update database
perl /home/program/Daemons/UpdateBlastDB/update_blastdb.pl \
	--directory "/media/Storage2/BlastDB" \
	--decompress \
	nt nr refseq_rna
