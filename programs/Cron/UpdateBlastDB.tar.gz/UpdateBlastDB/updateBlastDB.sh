#!/bin/bash

echo "Please modify the 'path/to/database' within the script before use!"
echo "Then you can remove these lines as well as the exit"
exit 0

here=$(pwd)
blastProgs="blastn|blastp|blastx|tblastn|tblastx"

#Ensure all blast jobs are done
blastJobs = ($(ps -e | grep -E $blastProgs))
while [ ${#blastJobs[@]} > 0 ]; do
	sleep 1m
	blastJobs = ($(ps -e | grep -E $blastProgs))
done

#Update database
cd /path/to/database
perl $here/update_blastdb.pl --decompress nt nr refseq_rna
cd $here
